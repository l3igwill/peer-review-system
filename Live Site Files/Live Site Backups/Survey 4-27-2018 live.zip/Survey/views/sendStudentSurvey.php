<div id="main">
    <?php

    ?>
        <div id="thankYou">
            <h3>Brent Presley <a href="mailto:Brent.Presley@mstc.edu">brent.presley@mstc.edu</a></h3>
            <h3>Jason Stroik <a href="mailto:jason.stroik@mstc.edu">jason.stroik@mstc.edu</a></h3>

            <p>Thank you for your feedback on
                <?php echo $_POST['reviewee']?>
            </p>
            <br>
            <p>Sincerely,</p>
            <div class="italic">
                <p>Brent Presely</p>
                <p>Instructor - Software Development</p>
                <p>Mid-State Technical College</p>
                <br>
                <p>Jason Stroik</p>
                <p>Instructor - Software Development</p>
                <p>Mid-State Technical College</p>
            </div>

        </div>

</div>
