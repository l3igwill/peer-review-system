<?php
session_start();
$_POST['action']='custSatisfaction';
include("index.php");
?>