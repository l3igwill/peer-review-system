<?php

$_POST["action"]='studentReport';
include("index.php");
?>
